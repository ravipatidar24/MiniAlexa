import pyttsx3
import speech_recognition as sr
import datetime
import wikipedia
import webbrowser
import os

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)

def speak(text):
    engine.say(text)
    engine.runAndWait()

def greet():
    hour = int(datetime.datetime.now().hour)
    
    if hour >= 0 and hour < 12:
        speak("Good Morning!")
    
    elif hour >= 12 and hour < 18:
        speak("Good Afternoon!")
    
    else:
        speak("Good Evening!")
    
    speak("I am MiniAlexa. Please tell me how may I help you")

def listen():
    recognizer = sr.Recognizer()
    
    with sr.Microphone() as source:
        print("Listening...")
        recognizer.pause_threshold = 1
        audio = recognizer.listen(source)
    
    try:
        print("Recognizing...")
        query = recognizer.recognize_google(audio, language='en-in')
        print(f"User said: {query}\n")
    
    except Exception:
        print("Say that again please...")
        return "None"
    
    return query.lower()

if __name__ == "__main__":
    greet()
    
    while True:
        command = listen()
        
        if 'wikipedia' in command:
            speak('Searching Wikipedia...')
            command = command.replace("wikipedia", "")
            results = wikipedia.summary(command, sentences=2)
            speak("According to Wikipedia")
            print(results)
            speak(results)
        
        elif 'open youtube' in command:
            webbrowser.open("youtube.com")
        
        elif 'open google' in command:
            webbrowser.open("google.com")
        
        elif 'open stackoverflow' in command:
            webbrowser.open("stackoverflow.com")
        
        elif 'the time' in command:
            current_time = datetime.datetime.now().strftime("%H:%M:%S")
            speak(f"Sir, the time is {current_time}")
        
        elif 'how are you' in command:
            speak("I am fine, thank you for asking. How can I assist you today?")
        
        elif 'who are you' in command:
            speak("I am MiniAlexa, your virtual assistant. How can I assist you today?")
        
        elif 'what can you do' in command:
            speak("I can help you with tasks such as searching on Wikipedia, opening websites, telling you the time, playing music, and answering your questions. How can I assist you today?")
        
        elif 'who made you' in command:
            speak("I was created by a team of skilled developers. How can I assist you today?")
        
        elif 'thank you' in command:
            speak("You're welcome! If you have any other questions, feel free to ask.")
        
        elif 'who is your boss' in command:
            speak("My boss is Ravi.")
        
        elif 'stop' in command:
            speak("Goodbye!")
            break
